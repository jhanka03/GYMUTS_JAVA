package com.gymadmin.service;
import com.gymadmin.model.Pago;
import com.gymadmin.repository.PagoRepository;
import org.springframework.stereotype.Service;
import java.util.List;import java.util.Optional;
@Service public class PagoService{ private final PagoRepository repo; public PagoService(PagoRepository repo){this.repo=repo;} public List<Pago> findAll(){return repo.findAll();} public Pago save(Pago e){return repo.save(e);} public Optional<Pago> findById(Long id){return repo.findById(id);} public void deleteById(Long id){repo.deleteById(id);} }
