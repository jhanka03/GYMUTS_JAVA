package com.gymadmin.model;
import jakarta.persistence.*;import jakarta.validation.constraints.NotBlank;
@Entity @Table(name = "entrenador")
public class Entrenador {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @NotBlank private String nombre; private String especialidad; private String telefono;
    public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getNombre(){return nombre;} public void setNombre(String nombre){this.nombre=nombre;} public String getEspecialidad(){return especialidad;} public void setEspecialidad(String e){this.especialidad=e;} public String getTelefono(){return telefono;} public void setTelefono(String t){this.telefono=t;}
}