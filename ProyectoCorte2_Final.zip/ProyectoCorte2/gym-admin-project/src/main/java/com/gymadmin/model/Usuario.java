package com.gymadmin.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
@Entity @Table(name="usuario") public class Usuario {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id; private String username; private String password; private String nombre; private String rol;
  public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getUsername(){return username;} public void setUsername(String u){this.username=u;} public String getPassword(){return password;} public void setPassword(String p){this.password=p;} public String getNombre(){return nombre;} public void setNombre(String n){this.nombre=n;} public String getRol(){return rol;} public void setRol(String r){this.rol=r;}
}