package com.gymadmin.service;
import com.gymadmin.model.Membresia;
import com.gymadmin.repository.MembresiaRepository;
import org.springframework.stereotype.Service;
import java.util.List;import java.util.Optional;
@Service public class MembresiaService{ private final MembresiaRepository repo; public MembresiaService(MembresiaRepository repo){this.repo=repo;} public List<Membresia> findAll(){return repo.findAll();} public Membresia save(Membresia e){return repo.save(e);} public Optional<Membresia> findById(Long id){return repo.findById(id);} public void deleteById(Long id){repo.deleteById(id);} }
