package com.gymadmin.controller;
import com.gymadmin.model.Entrenador; import com.gymadmin.service.EntrenadorService; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/entrenadors") public class EntrenadorController { private final EntrenadorService service; public EntrenadorController(EntrenadorService service){this.service=service;} @GetMapping public String list(Model model){ model.addAttribute("entrenadors", service.findAll()); return "entrenador/list"; } @GetMapping("/nuevo") public String nuevoForm(Model model){ model.addAttribute("entrenador", new Entrenador()); return "entrenador/form"; }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        var e = service.findById(id).orElseThrow(() -> new IllegalArgumentException("Id inválido"));
        model.addAttribute("entrenador", e);
        return "entrenador/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/entrenadores";
    }
}
 @PostMapping("/guardar") public String guardar(@ModelAttribute Entrenador e){ service.save(e); return "redirect:/entrenadors"; } }