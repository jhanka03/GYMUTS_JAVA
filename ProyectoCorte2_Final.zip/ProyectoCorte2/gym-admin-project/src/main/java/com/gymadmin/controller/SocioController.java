package com.gymadmin.controller;
import com.gymadmin.model.Socio; import com.gymadmin.service.SocioService;
import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.validation.BindingResult; import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
@Controller @RequestMapping("/socios") public class SocioController {
  private final SocioService service; public SocioController(SocioService service){this.service=service;}
  @GetMapping public String list(Model model){ model.addAttribute("socios", service.findAll()); return "socio/list"; }
  @GetMapping("/nuevo") public String nuevoForm(Model model){ model.addAttribute("socio", new Socio()); return "socio/form"; }
  @PostMapping("/guardar") public String guardar(@Valid @ModelAttribute Socio socio, BindingResult br){ if(br.hasErrors()) return "socio/form"; service.save(socio); return "redirect:/socios"; }
  @GetMapping("/editar/{id}") public String editar(@PathVariable Long id, Model model){ var s = service.findById(id).orElseThrow(() -> new IllegalArgumentException("Id inválido")); model.addAttribute("socio", s); return "socio/form"; }
  @GetMapping("/eliminar/{id}") public String eliminar(@PathVariable Long id){ service.deleteById(id); return "redirect:/socios"; }
}