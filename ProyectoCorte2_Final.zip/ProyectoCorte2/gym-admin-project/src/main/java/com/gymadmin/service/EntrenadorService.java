package com.gymadmin.service;
import com.gymadmin.model.Entrenador;
import com.gymadmin.repository.EntrenadorRepository;
import org.springframework.stereotype.Service;
import java.util.List;import java.util.Optional;
@Service public class EntrenadorService{ private final EntrenadorRepository repo; public EntrenadorService(EntrenadorRepository repo){this.repo=repo;} public List<Entrenador> findAll(){return repo.findAll();} public Entrenador save(Entrenador e){return repo.save(e);} public Optional<Entrenador> findById(Long id){return repo.findById(id);} public void deleteById(Long id){repo.deleteById(id);} }
