package com.gymadmin.config;

import com.gymadmin.model.Usuario;
import com.gymadmin.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataLoader {
    @Bean
    public CommandLineRunner loadInitialUsers(UsuarioRepository repo, PasswordEncoder encoder) {
        return args -> {
            if (repo.count() == 0) {
                Usuario u = new Usuario();
                u.setUsername("admin");
                u.setPassword(encoder.encode("adminpass"));
                u.setNombre("Administrador Gimnasio");
                u.setRol("ADMIN");
                repo.save(u);
            }
        };
    }
}
