package com.gymadmin.controller;
import com.gymadmin.model.Membresia; import com.gymadmin.service.MembresiaService; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/membresias") public class MembresiaController { private final MembresiaService service; public MembresiaController(MembresiaService service){this.service=service;} @GetMapping public String list(Model model){ model.addAttribute("membresias", service.findAll()); return "membresia/list"; } @GetMapping("/nuevo") public String nuevoForm(Model model){ model.addAttribute("membresia", new Membresia()); return "membresia/form"; }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        var e = service.findById(id).orElseThrow(() -> new IllegalArgumentException("Id inválido"));
        model.addAttribute("membresia", e);
        return "membresia/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/membresias";
    }
}
 @PostMapping("/guardar") public String guardar(@ModelAttribute Membresia e){ service.save(e); return "redirect:/membresias"; } }