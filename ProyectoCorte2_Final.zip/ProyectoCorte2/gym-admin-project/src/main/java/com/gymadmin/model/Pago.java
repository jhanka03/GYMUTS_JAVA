package com.gymadmin.model;
import jakarta.persistence.*;import java.math.BigDecimal;import java.time.LocalDateTime;
@Entity @Table(name="pago") public class Pago {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @ManyToOne @JoinColumn(name="socio_id") private Socio socio;
  private LocalDateTime fecha;

    @PrePersist
    public void prePersist() {
        if (this.fecha == null) this.fecha = LocalDateTime.now();
    }
 private BigDecimal monto;
  public Long getId(){return id;} public void setId(Long id){this.id=id;} public Socio getSocio(){return socio;} public void setSocio(Socio s){this.socio=s;} public LocalDateTime getFecha(){return fecha;} public void setFecha(LocalDateTime f){this.fecha=f;} public BigDecimal getMonto(){return monto;} public void setMonto(BigDecimal m){this.monto=m;}
}