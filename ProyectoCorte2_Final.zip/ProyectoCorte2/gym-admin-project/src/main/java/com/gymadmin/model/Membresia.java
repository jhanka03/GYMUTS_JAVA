package com.gymadmin.model;
import jakarta.persistence.*;import java.math.BigDecimal;import jakarta.validation.constraints.NotBlank;
@Entity @Table(name="membresia") public class Membresia {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @NotBlank private String tipo; private BigDecimal precio; private Integer duracionMeses;
  public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getTipo(){return tipo;} public void setTipo(String t){this.tipo=t;} public BigDecimal getPrecio(){return precio;} public void setPrecio(BigDecimal p){this.precio=p;} public Integer getDuracionMeses(){return duracionMeses;} public void setDuracionMeses(Integer d){this.duracionMeses=d;}
}