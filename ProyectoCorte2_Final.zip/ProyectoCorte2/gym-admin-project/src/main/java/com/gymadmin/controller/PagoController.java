package com.gymadmin.controller;
import com.gymadmin.model.Pago; import com.gymadmin.service.PagoService; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*;
@Controller @RequestMapping("/pagos") public class PagoController { private final PagoService service; public PagoController(PagoService service){this.service=service;} @GetMapping public String list(Model model){ model.addAttribute("pagos", service.findAll()); return "pago/list"; } @GetMapping("/nuevo") public String nuevoForm(Model model){ model.addAttribute("pago", new Pago()); return "pago/form"; }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        var p = service.findById(id).orElseThrow(() -> new IllegalArgumentException("Id inválido"));
        model.addAttribute("pago", p);
        model.addAttribute("socios", socioService.findAll());
        return "pago/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/pagos";
    }
}
 @PostMapping("/guardar") public String guardar(@ModelAttribute Pago e){ service.save(e); return "redirect:/pagos"; } }