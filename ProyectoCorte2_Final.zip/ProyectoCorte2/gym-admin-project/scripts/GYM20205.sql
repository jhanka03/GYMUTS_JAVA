-- GYM20205.sql
CREATE DATABASE IF NOT EXISTS GYM20205;
USE GYM20205;
... (script as provided in the project) ...
