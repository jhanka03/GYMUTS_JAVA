# GYM Admin - Proyecto (Entrega Profesional)

Proyecto Spring Boot + Thymeleaf para gestión de gimnasio, implementando los requisitos del PDF entregado: scripts SQL, DER, CRUDs, conexión a base de datos y documentación.

## Contenido
- Entidades: Usuario, Socio, Entrenador, Membresia, Pago.
- CRUD completo de Socios; CRUDs funcionales para Entrenador, Membresía y Pago (crear/editar/eliminar/listar).
- Seguridad básica: Spring Security con formulario de login y contraseña con BCrypt (usuario admin creado automáticamente).
- Estética: plantilla con menú lateral, Bootstrap 5 y estilos personalizados.

## Instalación rápida
1. Importar `scripts/GYM20205.sql` en MySQL.
2. Configurar `src/main/resources/application.properties` (usuario/clave DB).
3. `mvn clean package` y ejecutar `mvn spring-boot:run` o `java -jar target/gym-admin-0.0.1-SNAPSHOT.jar`.
4. Acceder a `http://localhost:8080` y usar credenciales: **admin / adminpass**.

## Notas
- Las contraseñas están hasheadas con BCrypt.
- Si deseas, puedo añadir paginación, reportes PDF y gráficas de uso.
