# Documento técnico

Este documento debe enriquecerse con capturas de pantalla y DER exportado.

- Importante: incluir evidencia en docs/evidences/
