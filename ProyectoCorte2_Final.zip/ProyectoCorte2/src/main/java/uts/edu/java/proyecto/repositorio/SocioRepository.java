package uts.edu.java.proyecto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import uts.edu.java.proyecto.modelo.Socio;

public interface SocioRepository extends JpaRepository<Socio, Long> {
}
