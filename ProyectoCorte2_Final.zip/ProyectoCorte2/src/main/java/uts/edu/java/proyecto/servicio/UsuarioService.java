package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.modelo.Usuario;
import uts.edu.java.proyecto.repositorio.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository repo;

    public UsuarioService(UsuarioRepository repo) {
        this.repo = repo;
    }

    public Optional<Usuario> findByUsername(String username) {
        return Optional.ofNullable(repo.findByUsername(username));
    }

    public void save(Usuario usuario) {
        repo.save(usuario);
    }
}
