package uts.edu.java.proyecto.servicio;

import org.springframework.stereotype.Service;
import uts.edu.java.proyecto.modelo.Entrenador;
import uts.edu.java.proyecto.repositorio.EntrenadorRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EntrenadorService {

    private final EntrenadorRepository repository;

    public EntrenadorService(EntrenadorRepository repository) {
        this.repository = repository;
    }

    public List<Entrenador> findAll() {
        return repository.findAll();
    }

    public Optional<Entrenador> findById(Long id) {
        return repository.findById(id);
    }

    public Entrenador save(Entrenador entrenador) {
        return repository.save(entrenador);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
