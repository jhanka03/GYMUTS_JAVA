package uts.edu.java.proyecto.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uts.edu.java.proyecto.modelo.Socio;
import uts.edu.java.proyecto.servicio.SocioService;

@Controller
@RequestMapping("/socio")
public class SocioController {

    private final SocioService service;

    public SocioController(SocioService service) {
        this.service = service;
    }

    // LISTAR
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("socios", service.findAll());
        return "socio/list";
    }

    // NUEVO SOCIO
    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("socio", new Socio());
        model.addAttribute("tipos", Socio.TipoMembresia.values()); // 👈 importante
        return "socio/form";
    }

    // GUARDAR
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Socio socio) {
        service.save(socio);
        return "redirect:/socio";
    }

    // EDITAR
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Socio socio = service.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("ID inválido: " + id));
        model.addAttribute("socio", socio);
        model.addAttribute("tipos", Socio.TipoMembresia.values());
        return "socio/form";
    }

    // ELIMINAR
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/socio";
    }
}
