package uts.edu.java.proyecto.controlador;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    // Página de login
    @GetMapping("/")
    public String mostrarLogin() {
        return "login"; // templates/login.html
    }

    // Procesar login
    @PostMapping("/login")
    public String procesarLogin(@RequestParam String usuario,
                                @RequestParam String contrasena,
                                HttpSession session,
                                Model model) {

        if ("admin".equals(usuario) && "1234".equals(contrasena)) {
            session.setAttribute("usuario", usuario);
            return "redirect:/panel";
        } else {
            model.addAttribute("error", "Usuario o contraseña incorrectos");
            return "login";
        }
    }

    // Página principal (panel)
    @GetMapping("/panel")
    public String mostrarPanel(HttpSession session) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/";
        }
        return "index";
    }
    
    @GetMapping("/membresias")
    public String mostrarMembresias() {
        return "membresias";
    }

    @GetMapping("/pagos")
    public String mostrarPagos() {
        return "pagos"; // Debe existir templates/pagos.html
    }
    

    // 🔴 Cerrar sesión (solo POST)
    @PostMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "logout"; // templates/logout.html
    }
}
