package uts.edu.java.proyecto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import uts.edu.java.proyecto.modelo.Entrenador;

public interface EntrenadorRepository extends JpaRepository<Entrenador, Long> {
}
