package uts.edu.java.proyecto.servicio;

import org.springframework.stereotype.Service;
import uts.edu.java.proyecto.modelo.Socio;
import uts.edu.java.proyecto.repositorio.SocioRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SocioService {

    private final SocioRepository repository;

    public SocioService(SocioRepository repository) {
        this.repository = repository;
    }

    public List<Socio> findAll() {
        return repository.findAll();
    }

    public Optional<Socio> findById(Long id) {
        return repository.findById(id);
    }

    public Socio save(Socio socio) {
        return repository.save(socio);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
